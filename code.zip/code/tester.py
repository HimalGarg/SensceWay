from main import auto_send_whatsapp

auto_send_whatsapp("+919354139640","Hello" )